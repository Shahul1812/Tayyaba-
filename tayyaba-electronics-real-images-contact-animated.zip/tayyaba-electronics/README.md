# TAYYABA ELECTRONICS

Complete responsive frontend e-commerce demo with 160 catalog records (20 each across 8 categories).

## Important image note
Local SVG demo assets are included for all 160 products so there are no broken image dependencies. They are clearly demo assets, not claimed manufacturer photographs. Replace them with properly licensed real product photos before production.

## Price note
Prices are reference/demo values, not verified live offers. Verify current Indian-market prices before publishing.

## Contact
The homepage Contact Us button opens the supplied Google Form in a new tab.

Open `index.html` directly or serve the folder using a static web server.


## Product photography update
The catalog now uses fixed real-world electronics/appliance photographs from Unsplash for the demo presentation. Product names/specifications remain demo catalog data; photographs are category-matched rather than guaranteed to depict the exact listed model. For exact manufacturer model photography, replace each category image URL with appropriately licensed manufacturer assets.

## Contact CTA
Every primary navigation Contact button now opens the supplied Google Form directly. The Contact CTA has a color-changing gradient, bounce motion, glow pulse, and reduced-motion accessibility fallback.
